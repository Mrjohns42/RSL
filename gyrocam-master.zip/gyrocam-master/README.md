Gyro Cam
=======

Project for LPC Xpresso with LPC1114 and MPU-6050
