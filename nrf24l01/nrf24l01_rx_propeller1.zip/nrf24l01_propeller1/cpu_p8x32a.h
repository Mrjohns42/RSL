/*
 * @author
 * Copyright (C) 2012 Luis R. Hilario http://www.luisdigital.com
 *
 */

#include "propeller.h"
#include "spi.h"

/*
 * SPI pins:
 * MOSI: P0
 * MISO: P1
 * SCK : P2
 * CSN : P3
 * CE   : P4
 */

/* CE is set to output */
#define NRF24L01_CE_OUT        DIRA  |= _CE;

#define NRF24L01_CE_HIGH       OUTA |= _CE;
#define NRF24L01_CE_LOW       OUTA &= ~_CE;
#define NRF24L01_CSN_HIGH    OUTA |= _CSN;
#define NRF24L01_CSN_LOW    OUTA &= ~_CSN;

void Delay_Init(void);
void Delay_us(int us);
char SPI(char TX_Data);
