/** @mainpage
 @version 0.9
 @author
  Copyright (C) 2012 Luis R. Hilario http://www.luisdigital.com

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

 @section intro Introduction
 This library is intended to be universal and easy to use.
 
 Download source code here: http://www.luisdigital.com/proyectos/nrf24l01/nrf24l01.zip

 The files cpu_*.* contain code for a specific processor.

 Examples included for the following processors:

 NXP LPC11xx, LPC13xx "cpu_lpc1000.h"

 NXP LPC17xx "cpu_lpc1700.h"

 Parallax Propeller 1 "cpu_p8x32a.h"

 You can also provide examples for other micros.
 
 Please report any bug and / or solution you find.
*/

#include "propeller.h"
#include "spi.h"

void SPI_Init(void) {
  DIRA |= _CSN | _SCK | _MOSI;
  DIRA &= ~_MISO;

  OUTA &= ~_SCK; // SCK = 0 Modo 0, SCK = 1 Modo 3
  OUTA |= _CSN;
}

char SPI_WR(char Byte_Out) {
int i;
char result = 0;

    for (i = 7; i > -1; i--) {
        if (((Byte_Out >> i) & 1) == 1) OUTA |= _MOSI; 
            else  OUTA &= ~_MOSI;

       if ((INA & _MISO) == _MISO) result |= (1<<i); 

       OUTA |= _SCK;
       OUTA &= ~_SCK;


    }

   return result;

}