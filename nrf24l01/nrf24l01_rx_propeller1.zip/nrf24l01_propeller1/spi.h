/*
 * @author
 * Copyright (C) 2012 Luis R. Hilario http://www.luisdigital.com
 *
 */

/*
 * SPI pins:
 * MOSI: P0
 * MISO: P1
 * SCK : P2
 * CSN : P3
 * CE   : P4
 */

#define  _MOSI  (1 << 0)
#define  _MISO  (1 << 1)
#define  _SCK   (1 << 2)
#define  _CSN   (1 << 3)
#define _CE      (1 << 4)

void SPI_Init(void);
char SPI_WR(char Byte_Out);