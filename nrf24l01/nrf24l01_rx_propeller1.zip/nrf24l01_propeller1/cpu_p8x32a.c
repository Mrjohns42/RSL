/*
 * @author
 * Copyright (C) 2012 Luis R. Hilario http://www.luisdigital.com
 *
 */

#include "cpu_p8x32a.h"

void Delay_us(int us) {
    us = 1000000 / us; 
    waitcnt(CLKFREQ / us + CNT);
}

char SPI(char TX_Data) {
    return SPI_WR(TX_Data);
//SPI_Out(TX_Data);

//return SPI_In();
}
